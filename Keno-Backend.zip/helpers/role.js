
export const admin = "admin";
export const superadmin = "superadmin";
export const cashier = "cashier";
